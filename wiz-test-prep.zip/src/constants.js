const CONFIG ={
    PORT:3000,
    DB_URL: 'mongodb://127.0.0.1/wizard-creatures',
    SECRET:'0b4b114a-692c-11ee-8c99-0242ac120002'
}

module.exports = CONFIG